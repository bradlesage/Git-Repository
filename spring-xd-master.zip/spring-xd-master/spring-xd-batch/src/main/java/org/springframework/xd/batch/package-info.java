/**
 * Package for XD batch database support.
 */

package org.springframework.xd.batch;
