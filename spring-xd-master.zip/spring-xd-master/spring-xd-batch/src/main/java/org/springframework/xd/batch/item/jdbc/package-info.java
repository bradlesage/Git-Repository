/**
 * Package for JDBC item provider.
 */

package org.springframework.xd.batch.item.jdbc;
