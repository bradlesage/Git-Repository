/**
 * Package with core abstractions for Machine Learning Support.
 * @author Thomas Darimont
 */

package org.springframework.xd.analytics.ml;
