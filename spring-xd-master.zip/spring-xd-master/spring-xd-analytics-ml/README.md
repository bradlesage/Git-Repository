Spring XD Analytics ML
======================
