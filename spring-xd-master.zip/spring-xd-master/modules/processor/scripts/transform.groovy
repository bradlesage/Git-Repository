/**
 * Simple implementation of a Spring Integration transformer
 that leaves the payload unmodified
 *
 */
return payload