-- default script uses stream name as table name
drop table #table;
create table #table (#columns);
