/**
 * Package for core metrics.
 */

package org.springframework.xd.analytics.metrics.core;
