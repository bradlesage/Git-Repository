/**
 * Package for Redis based metrics support.
 */

package org.springframework.xd.analytics.metrics.redis;
