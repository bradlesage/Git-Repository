/**
 * Package for in-memory metrics.
 */

package org.springframework.xd.analytics.metrics.memory;
