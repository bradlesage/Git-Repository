/**
 * Package for metrics' options metadata.
 */

package org.springframework.xd.analytics.metrics.metadata;
