/**
 * Package for analytics repository.
 */

package org.springframework.xd.store;
