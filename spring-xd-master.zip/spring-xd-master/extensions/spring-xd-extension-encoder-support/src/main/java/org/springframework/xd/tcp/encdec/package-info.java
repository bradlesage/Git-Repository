/**
 * Package for encoders/decoders config for TCP extensions.
 */

package org.springframework.xd.tcp.encdec;

