/**
 * Package for SYSLOG extensions.
 */

package org.springframework.xd.syslog;
