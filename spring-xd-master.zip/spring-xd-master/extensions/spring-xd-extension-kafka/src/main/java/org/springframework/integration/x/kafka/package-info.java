/**
 * Package for kafka integration extensions.
 */

package org.springframework.integration.x.kafka;
