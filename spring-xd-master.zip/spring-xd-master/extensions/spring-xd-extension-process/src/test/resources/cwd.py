import os
import sys
import time
print os.getcwd()
sys.stdout.flush()
time.sleep(10)
