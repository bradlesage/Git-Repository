/**
 * Package for Mail module extensions.
 */

package org.springframework.xd.mail;
