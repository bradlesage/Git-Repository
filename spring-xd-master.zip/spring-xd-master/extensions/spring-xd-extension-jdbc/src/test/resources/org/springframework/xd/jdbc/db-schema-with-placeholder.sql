drop table #table;
create table #table (#columns);
