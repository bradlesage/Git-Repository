/**
 * Package for twitter integration extensions.
 */

package org.springframework.integration.x.twitter;
