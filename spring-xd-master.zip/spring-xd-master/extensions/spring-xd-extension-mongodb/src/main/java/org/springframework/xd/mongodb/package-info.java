/**
 * Package for mongodb extensions.
 */

package org.springframework.xd.mongodb;
