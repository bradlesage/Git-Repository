/**
 * Package for Reactor integration for syslog.
 */

package org.springframework.xd.integration.reactor.syslog;
