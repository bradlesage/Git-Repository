/**
 * Package for Splunk extensions.
 */

package org.springframework.xd.splunk;
