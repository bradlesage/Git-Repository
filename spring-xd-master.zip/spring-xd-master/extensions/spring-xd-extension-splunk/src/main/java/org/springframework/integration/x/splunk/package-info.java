/**
 * Package for Splunk integration extensions.
 */

package org.springframework.integration.x.splunk;
