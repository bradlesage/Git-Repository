/**
 * Package for throughput sampler extensions.
 */

package org.springframework.xd.integration.throughput;
