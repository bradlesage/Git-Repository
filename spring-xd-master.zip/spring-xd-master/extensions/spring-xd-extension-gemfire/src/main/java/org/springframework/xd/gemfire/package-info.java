/**
 * Package for gemfire extensions.
 */

package org.springframework.xd.gemfire;
