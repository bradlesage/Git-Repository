/**
 * Package for Gemfire integration extensions.
 */

package org.springframework.integration.x.gemfire;
