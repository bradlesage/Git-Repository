/**
 * Package for batch integration classes.
 */

package org.springframework.integration.x.http;
