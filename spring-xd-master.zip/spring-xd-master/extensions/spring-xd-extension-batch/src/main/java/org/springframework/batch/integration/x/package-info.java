/**
 * Package for Batch integration extensions.
 */

package org.springframework.batch.integration.x;
